from flask import Flask, render_template, request, redirect, url_for
import os

app = Flask(__name__)

app.config['FLASK_TITLE'] = ""

# --- IN-MEMORY DATA STRUCTURES (Students will modify this area) ---
# Phase 1: A simple Python List to store contacts
contacts = [
    {'name': 'John Smith', 'email': 'john.smith@email.com'},
    {'name': 'Sarah Johnson', 'email': 'sarah.johnson@email.com'},
    {'name': 'Michael Brown', 'email': 'mbrown@email.com'},
    {'name': 'Emily Davis', 'email': 'emily.davis@email.com'},
    {'name': 'David Wilson', 'email': 'd.wilson@email.com'},
    {'name': 'Jessica Martinez', 'email': 'j.martinez@email.com'},
    {'name': 'Christopher Lee', 'email': 'c.lee@email.com'},
    {'name': 'Amanda Taylor', 'email': 'amanda.t@email.com'},
    {'name': 'Ryan Anderson', 'email': 'ryananderson@email.com'},
    {'name': 'Nicole Garcia', 'email': 'nicole.garcia@email.com'},
] 

# --- ROUTES ---

@app.route('/')
def index():
    """
    Displays the main page.
    Eventually, students will pass their Linked List or Tree data here.
    """
    search_query = request.args.get('search', '').lower()
    filtered_contacts = contacts
    
    if search_query:
        filtered_contacts = [c for c in contacts 
                           if search_query in c['name'].lower() 
                           or search_query in c['email'].lower()]
    
    return render_template('index.html', 
                         contacts=filtered_contacts,
                         all_contacts=contacts,
                         search_query=search_query,
                         title=app.config['FLASK_TITLE'])

@app.route('/add', methods=['POST'])
def add_contact():
    """
    Endpoint to add a new contact.
    Students will update this to insert into their Data Structure.
    """
    name = request.form.get('name')
    email = request.form.get('email')
    
    # Phase 1 Logic: Append to list
    if name and email:  # Validate inputs
        contacts.append({'name': name, 'email': email})
    
    return redirect(url_for('index'))

@app.route('/search', methods=['GET'])
def search():
    """
    Endpoint to search for contacts by name or email.
    """
    search_query = request.args.get('search', '').lower()
    filtered_contacts = []
    
    if search_query:
        filtered_contacts = [c for c in contacts 
                           if search_query in c['name'].lower() 
                           or search_query in c['email'].lower()]
    
    return render_template('index.html',
                         contacts=filtered_contacts,
                         all_contacts=contacts,
                         search_query=search_query,
                         search_performed=True,
                         title=app.config['FLASK_TITLE'])

# --- DATABASE CONNECTIVITY (For later phases) ---
# Placeholders for students to fill in during Sessions 5 and 27
def get_postgres_connection():
    pass

def get_mssql_connection():
    pass

if __name__ == '__main__':
    # Run the Flask app on port 5000, accessible externally
    app.run(host='0.0.0.0', port=5000, debug=True)
